-- If you already ran the earlier schema, run only this upgrade (it does not re-add seed data).
alter table public.registrations
  add column if not exists receipt_path text,
  add column if not exists utr text,
  add column if not exists receipt_at timestamptz;

alter table public.registrations drop constraint if exists registrations_payment_status_check;
alter table public.registrations add constraint registrations_payment_status_check
  check (payment_status in ('pending','submitted','paid','refunded'));


-- ===== Payment receipts =====
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('receipts', 'receipts', false, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "receipts upload own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'receipts' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "receipts read own" on storage.objects for select to authenticated
  using (bucket_id = 'receipts' and (storage.foldername(name))[1] = (select auth.uid())::text);

create or replace function public.submit_receipt(p_registration bigint, p_path text, p_utr text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'login required'; end if;
  if p_path is null or p_path not like auth.uid()::text || '/%' then raise exception 'invalid path'; end if;
  if nullif(trim(p_utr), '') is not null and trim(p_utr) !~ '^[0-9A-Za-z]{6,30}$' then raise exception 'invalid utr'; end if;
  update public.registrations
     set receipt_path = p_path, utr = nullif(trim(p_utr), ''), receipt_at = now(),
         payment_status = case when payment_status = 'paid' then 'paid' else 'submitted' end
   where id = p_registration and user_id = auth.uid();
  if not found then raise exception 'registration not found'; end if;
end $$;

revoke all on function public.submit_receipt(bigint, text, text) from public, anon;
grant execute on function public.submit_receipt(bigint, text, text) to authenticated;

create or replace function public.book_slot(
  p_tournament bigint, p_team text, p_captain text, p_uid text, p_phone text, p_mates jsonb
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare t public.tournaments%rowtype; n integer; rid bigint;
begin
  if auth.uid() is null then raise exception 'login required'; end if;
  if p_uid !~ '^[0-9]{8,12}$' then raise exception 'invalid uid'; end if;
  if p_phone !~ '^[6-9][0-9]{9}$' then raise exception 'invalid phone'; end if;
  if length(trim(p_team)) not between 1 and 24 or length(trim(p_captain)) not between 1 and 30 then raise exception 'invalid name'; end if;
  select * into t from public.tournaments where id = p_tournament for update;
  if not found then raise exception 'tournament not found'; end if;
  if t.filled >= t.slots then raise exception 'slots full'; end if;
  insert into public.registrations (tournament_id, user_id, team, captain, uid, phone, mates)
    values (p_tournament, auth.uid(), trim(p_team), trim(p_captain), p_uid, p_phone, coalesce(p_mates, '[]'::jsonb))
    returning id into rid;
  update public.tournaments set filled = filled + 1 where id = p_tournament returning filled into n;
  return jsonb_build_object('slot', n, 'fee', t.fee, 'name', t.name, 'reg', rid);
end $$;

-- ===== Profile screenshots (UID verification) =====
alter table public.registrations
  add column if not exists profile_path text,
  add column if not exists uid_status text not null default 'pending';
alter table public.registrations drop constraint if exists registrations_uid_status_check;
alter table public.registrations add constraint registrations_uid_status_check
  check (uid_status in ('pending','verified','rejected'));

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('profiles', 'profiles', false, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
create policy "profiles upload own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'profiles' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "profiles read own" on storage.objects for select to authenticated
  using (bucket_id = 'profiles' and (storage.foldername(name))[1] = (select auth.uid())::text);

drop function if exists public.book_slot(bigint, text, text, text, text, jsonb);
create or replace function public.book_slot(
  p_tournament bigint, p_team text, p_captain text, p_uid text, p_phone text, p_mates jsonb, p_profile_path text
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare t public.tournaments%rowtype; n integer; rid bigint;
begin
  if auth.uid() is null then raise exception 'login required'; end if;
  if p_uid !~ '^[0-9]{8,12}$' then raise exception 'invalid uid'; end if;
  if p_phone !~ '^[6-9][0-9]{9}$' then raise exception 'invalid phone'; end if;
  if length(trim(p_team)) not between 1 and 24 or length(trim(p_captain)) not between 1 and 30 then raise exception 'invalid name'; end if;
  if p_profile_path is null or p_profile_path not like auth.uid()::text || '/%' then raise exception 'profile screenshot required'; end if;
  select * into t from public.tournaments where id = p_tournament for update;
  if not found then raise exception 'tournament not found'; end if;
  if t.filled >= t.slots then raise exception 'slots full'; end if;
  insert into public.registrations (tournament_id, user_id, team, captain, uid, phone, mates, profile_path)
    values (p_tournament, auth.uid(), trim(p_team), trim(p_captain), p_uid, p_phone, coalesce(p_mates, '[]'::jsonb), p_profile_path)
    returning id into rid;
  update public.tournaments set filled = filled + 1 where id = p_tournament returning filled into n;
  return jsonb_build_object('slot', n, 'fee', t.fee, 'name', t.name, 'reg', rid);
end $$;
revoke all on function public.book_slot(bigint, text, text, text, text, jsonb, text) from public, anon;
grant execute on function public.book_slot(bigint, text, text, text, text, jsonb, text) to authenticated;
